
frame_functions2 = [];
frame_functions = [];
function delayFrame(func) {
	frame_functions2.push(func);
}
function frame() {
    requestAnimationFrame(frame);

    while(frame_functions.length > 0) {
    	(frame_functions.pop())();
    }

    frame_functions = frame_functions2;
    frame_functions2 = [];
}
frame();



function lerp(v0, v1, t) {
    return v0*(1-t)+v1*t
}

function shuffleArray(array) {
    for (var i = array.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    return array;
}

function HSVtoColor(h, s, v) {
    var r, g, b, i, f, p, q, t;
    if (arguments.length === 1) {
        s = h.s, v = h.v, h = h.h;
    }
    i = Math.floor(h * 6);
    f = h * 6 - i;
    p = v * (1 - s);
    q = v * (1 - f * s);
    t = v * (1 - (1 - f) * s);
    switch (i % 6) {
        case 0: r = v, g = t, b = p; break;
        case 1: r = q, g = v, b = p; break;
        case 2: r = p, g = v, b = t; break;
        case 3: r = p, g = q, b = v; break;
        case 4: r = t, g = p, b = v; break;
        case 5: r = v, g = p, b = q; break;
    }
    return "#"+("00"+Math.round(r * 255).toString(16)).substr(-2)+("00"+Math.round(g * 255).toString(16)).substr(-2)+("00"+Math.round(b * 255).toString(16)).substr(-2);
}
